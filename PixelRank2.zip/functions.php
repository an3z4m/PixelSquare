<?php

define('ROOT_THEME_DIR', get_template_directory());
define('ROOT_THEME_URL', get_template_directory_uri());

